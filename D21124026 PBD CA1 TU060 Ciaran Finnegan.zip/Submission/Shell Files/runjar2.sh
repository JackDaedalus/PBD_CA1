#!/bin/bash
echo " "
# Run Java Jar file
echo " "
echo " "
echo "Run Java Jar file..."
echo " "
hadoop jar AverageLetterFrequency.jar gutenbergBooks/*_Italian CA1_Output
# hadoop jar AverageLetterFrequency.jar gutenbergBooks/*_English CA1_Output
# hadoop jar AverageLetterFrequency.jar gutenbergBooks/*_German CA1_Output
# hadoop jar AverageLetterFrequency.jar gutenbergBooks/*_Spanish CA1_Output
# hadoop jar AverageLetterFrequency.jar gutenbergBooks/*_French CA1_Output
